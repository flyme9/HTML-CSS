<template>
    <div>
        cinemas
        <router-view></router-view>
    </div>
</template>
