<template>
    <div>
        nowPlay
    </div>
</template>
